webpackJsonp([33],{

/***/ 1824:
/***/ (function(module, exports) {

module.exports = {"dependencies":{"echarts":"^4.2.0-rc.2"}}

/***/ })

});